
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('auctions', '0002_bid_category_comment_listing'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='listing',
            name='photo',
        ),
        migrations.AddField(
            model_name='listing',
            name='image_url',
            field=models.URLField(default='google.com'),
        ),
    ]
